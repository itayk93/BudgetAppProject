import SwiftUI
import UIKit

struct PendingTransactionsReviewView: View {
    @StateObject private var viewModel = PendingTransactionsReviewViewModel()
    @State private var dragOffset: CGSize = .zero
    @State private var pendingCategoryChange: Transaction?
    @State private var pendingNoteEntry: Transaction?
    @State private var toastMessage: String?
    @State private var startSplitFlow = false
    @Environment(\.dismiss) private var dismiss

    private let swipeThreshold: CGFloat = 110

    private var currentTransaction: Transaction? {
        viewModel.transactions.first
    }

    var body: some View {
        ZStack(alignment: .top) {
            Color.groupedBackground.ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 20) {
                    heroSection
                    Spacer().frame(height: 24)
                }
                .frame(maxWidth: .infinity, alignment: .center)
                .padding(.horizontal, 20)
                .padding(.top, 18)
                .padding(.bottom, 24)
            }
        }
        .navigationTitle("אישור עסקאות")
        .navigationBarTitleDisplayMode(.inline)
        .task {
            print("📱 [DEBUG] View loaded, starting refresh...")
            await viewModel.refresh()
        }
        .refreshable {
            print("📱 [DEBUG] Pull to refresh triggered")
            await viewModel.refresh()
        }
        .sheet(item: $pendingCategoryChange, onDismiss: {
            startSplitFlow = false
        }) { transaction in
            CategorySelectionSheet(
                transaction: transaction,
                categories: viewModel.categories,
                startWithSplit: startSplitFlow,
                onSelect: { category, note in
                    Task {
                        await viewModel.reassign(transaction, to: category, note: note)
                    }
                },
                onSelectForFuture: { category, note in
                    Task {
                        await viewModel.reassignForFuture(transaction, to: category, note: note)
                    }
                },
                onDelete: {
                    Task {
                        await viewModel.delete(transaction)
                    }
                },
                onHideBusiness: {
                    Task {
                        await viewModel.hideBusiness(transaction)
                    }
                },
                onSplit: { originalTransactionId, splits in
                    Task {
                        do {
                            try await viewModel.splitTransaction(
                                transaction,
                                originalTransactionId: originalTransactionId,
                                splits: splits
                            )
                        } catch {
                            // Handle error appropriately
                            print("❌ splitTransaction failed:", error)
                        }
                    }
                }
            )
        }
        .sheet(item: $pendingNoteEntry) { transaction in
            let transactionID = transaction.id
            NoteEntrySheet(
                transaction: transaction,
                isSaving: viewModel.processingTransactionID == transaction.id
            ) { text in
                return await viewModel.saveNote(text, for: transactionID)
            }
        }
        .overlay(alignment: .top) {
            if let toastMessage {
                toastView(message: toastMessage)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .padding(.top, 12)
                    .padding(.horizontal, 24)
            }
        }
        .onChange(of: viewModel.actionMessage) { _, newValue in
            guard let newValue else { return }
            toastMessage = newValue
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.4) {
                if toastMessage == newValue {
                    withAnimation {
                        toastMessage = nil
                    }
                    viewModel.actionMessage = nil
                }
            }
        }
        .onChange(of: viewModel.transactions.first?.id) { _, _ in
            dragOffset = .zero
        }
        .environment(\.layoutDirection, .rightToLeft)
    }

    @ViewBuilder
    private var heroSection: some View {
        if let transaction = currentTransaction {
            heroCardView(transaction)
        } else if viewModel.loading {
            heroLoadingPlaceholder
        } else {
            heroEmptyState
        }
    }

    private func heroCardView(_ transaction: Transaction) -> some View {
        VStack(spacing: 0) {
            VStack(alignment: .trailing, spacing: 10) {
                HStack {
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 32, height: 32)
                            .background(Color.black.opacity(0.25))
                            .clipShape(Circle())
                    }
                }
                Text("הוצאות משתנות")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .multilineTextAlignment(.trailing)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                Text("\(currencySymbol(for: transaction.currency))\(heroAmountText(transaction.absoluteAmount))")
                    .font(.system(size: 42, weight: .bold))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.trailing)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                VStack(alignment: .trailing, spacing: 4) {
                    Text(transaction.business_name ?? transaction.payment_method ?? "עסקה ממתינה")
                        .font(.headline)
                        .foregroundColor(.white.opacity(0.95))
                        .multilineTextAlignment(.trailing)
                        .frame(maxWidth: .infinity, alignment: .trailing)
                    Text(transaction.payment_method ?? "כרטיס • \(String(transaction.id.suffix(4)))")
                        .font(.footnote)
                        .foregroundColor(.white.opacity(0.85))
                        .multilineTextAlignment(.trailing)
                        .frame(maxWidth: .infinity, alignment: .trailing)
                    Text(formattedPaymentDate(for: transaction))
                        .font(.caption2)
                        .foregroundColor(.white.opacity(0.75))
                        .multilineTextAlignment(.trailing)
                        .frame(maxWidth: .infinity, alignment: .trailing)
                }
            }
            .frame(maxWidth: .infinity, alignment: .trailing)
            .padding(.horizontal, 24)
            .padding(.top, 20)
            .padding(.bottom, 16)
            .background(heroYellowColor)

            VStack(spacing: 12) {
                ForEach(heroActions(for: transaction)) { action in
                    heroActionButton(action)
                }
                if viewModel.transactions.count > 1 {
                    Text("נותרו עוד \(viewModel.transactions.count - 1) טרנזקציות ממתינות")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity, alignment: .trailing)
                }
            }
            .padding(.horizontal, 12)
            .padding(.top, 18)
            .padding(.bottom, 20)
        }
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 32, style: .continuous))
        .shadow(color: Color.black.opacity(0.08), radius: 16, x: 0, y: 8)
        .padding(.horizontal, 20)
        .offset(x: dragOffset.width, y: 0)
        .rotationEffect(.degrees(Double(dragOffset.width / 10)))
        .animation(.interactiveSpring(), value: dragOffset)
        .gesture(heroDragGesture(for: transaction))
        .onTapGesture {
            guard viewModel.processingTransactionID == nil && pendingCategoryChange == nil else { return }
            pendingCategoryChange = transaction
        }
        .allowsHitTesting(viewModel.processingTransactionID == nil && pendingCategoryChange == nil)
    }

    private func heroDragGesture(for transaction: Transaction) -> some Gesture {
        LongPressGesture(minimumDuration: 0.25)
            .sequenced(before: DragGesture(minimumDistance: 0))
            .onChanged { value in
                guard viewModel.processingTransactionID == nil && pendingCategoryChange == nil else { return }
                if case .second(true, let drag?) = value {
                    dragOffset = CGSize(width: drag.translation.width, height: 0)
                }
            }
            .onEnded { value in
                guard viewModel.processingTransactionID == nil && pendingCategoryChange == nil else {
                    withAnimation(.spring()) {
                        dragOffset = .zero
                    }
                    return
                }
                if case .second(true, let drag?) = value {
                    handleDragEnd(translationX: drag.translation.width, transaction: transaction)
                } else {
                    withAnimation(.spring()) {
                        dragOffset = .zero
                    }
                }
            }
    }

    private func heroActionButton(_ action: HeroAction) -> some View {
        Button {
            action.action()
        } label: {
            HStack(spacing: 12) {
                Text(action.title)
                    .font(.body.weight(.semibold))
                    .foregroundColor(.primary)
                Spacer()
                Image(systemName: action.icon)
                    .font(.title3)
                    .foregroundColor(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .trailing)
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(Color(UIColor.systemGray6))
                    .shadow(color: Color.black.opacity(0.06), radius: 6, x: 0, y: 3)
            )
        }
        .buttonStyle(.plain)
    }

    private func heroActions(for transaction: Transaction) -> [HeroAction] {
        [
            HeroAction(id: "note", icon: "text.bubble", title: "להוסיף הערה") {
                pendingNoteEntry = transaction
            },
            HeroAction(id: "move", icon: "arrowshape.turn.up.right", title: "להזיז את ההוצאה") {
                pendingCategoryChange = transaction
            },
            HeroAction(id: "split", icon: "scissors", title: "לפצל את ההוצאה") {
                startSplitFlow = true
                pendingCategoryChange = transaction
            },
            HeroAction(id: "savings", icon: "banknote", title: "זה הפקדה לחיסכון!") {
                showToastMessage("סומן כהפקדה לחיסכון.")
            }
        ]
    }

    private var heroLoadingPlaceholder: some View {
        VStack(spacing: 12) {
            ProgressView()
                .progressViewStyle(CircularProgressViewStyle(tint: .accentColor))
            Text("טוען עסקאות ממתינות...")
                .font(.footnote)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(24)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .shadow(color: Color.black.opacity(0.08), radius: 12, x: 0, y: 6)
        .padding(.horizontal, 20)
    }

    private var heroEmptyState: some View {
        VStack(spacing: 8) {
            Text("אין טרנזקציות ממתינות")
                .font(.headline)
            Text("רענן את המסך כדי לבדוק אם הגיעו עסקאות חדשות.")
                .font(.footnote)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(24)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .shadow(color: Color.black.opacity(0.08), radius: 12, x: 0, y: 6)
        .padding(.horizontal, 20)
    }

    private func heroAmountText(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.locale = Locale(identifier: "he_IL")
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = value.truncatingRemainder(dividingBy: 1) == 0 ? 0 : 1
        formatter.minimumFractionDigits = 0
        return formatter.string(from: NSNumber(value: value)) ?? "0"
    }

    private func formattedPaymentDate(for transaction: Transaction) -> String {
        guard let date = transaction.parsedDate else {
            return "תאריך לא זמין"
        }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "he_IL")
        formatter.dateStyle = .short
        formatter.timeStyle = .none
        return formatter.string(from: date)
    }

    private func currencySymbol(for code: String?) -> String {
        guard let code else { return "₪" }
        let formatter = NumberFormatter()
        formatter.locale = Locale(identifier: "he_IL")
        formatter.numberStyle = .currency
        formatter.currencyCode = code
        return formatter.currencySymbol ?? "₪"
    }

    private func showToastMessage(_ message: String) {
        toastMessage = message
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.4) {
            if toastMessage == message {
                withAnimation {
                    toastMessage = nil
                }
            }
        }
    }

    private var heroYellowColor: Color {
        Color(red: 241/255, green: 193/255, blue: 26/255)
    }

    private func handleDragEnd(translationX: CGFloat, transaction: Transaction) {
        if translationX > swipeThreshold {
            animateHeroExit(to: swipeThreshold * 1.8)
            Task { await viewModel.approve(transaction) }
        } else if translationX < -swipeThreshold {
            animateHeroExit(to: -swipeThreshold * 1.8)
            pendingCategoryChange = transaction
        } else {
            withAnimation(.spring()) {
                dragOffset = .zero
            }
        }
    }

    private func animateHeroExit(to offset: CGFloat) {
        withAnimation(.easeOut(duration: 0.25)) {
            dragOffset = CGSize(width: offset, height: 0)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
            withAnimation(.spring()) {
                dragOffset = .zero
            }
        }
    }

    private func toastView(message: String) -> some View {
        HStack {
            Image(systemName: "checkmark")
                .foregroundColor(.white)
            Text(message)
                .font(.footnote)
                .foregroundColor(.white)
        }
        .padding(.vertical, 12)
        .padding(.horizontal, 18)
        .background(Color.black.opacity(0.8))
        .clipShape(Capsule())
    }

}
 

private struct HeroAction: Identifiable {
    let id: String
    let icon: String
    let title: String
    let action: () -> Void
}

// The CategorySelectionSheet would be defined here as a private struct
private struct CategorySelectionSheet: View {
    let transaction: Transaction
    let categories: [TransactionCategory]
    var startWithSplit: Bool = false
    var onSelect: (String, String?) -> Void
    var onSelectForFuture: (String, String?) -> Void
    var onDelete: () -> Void
    var onHideBusiness: () -> Void
    var onSplit: (String, [SplitTransactionEntry]) -> Void

    @State private var searchText: String = ""
    @State private var noteText: String = ""
    @State private var pendingCategory: String?
    @State private var showFutureChoice = false
    @State private var showHideConfirmation = false
    @State private var isCategoryPickerExpanded = false
    @State private var isNoteEditorExpanded = false
    @State private var showSplitSheet = false
    @FocusState private var focusedField: Field?
    @Environment(\.dismiss) private var dismiss

    private var trimmedSearchText: String {
        searchText.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var filteredCategories: [TransactionCategory] {
        guard !trimmedSearchText.isEmpty else { return categories }
        return categories.filter { category in
            category.name.localizedCaseInsensitiveContains(trimmedSearchText)
        }
    }

    private var trimmedNote: String? {
        let trimmed = noteText.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }

    private var noteButtonSubtitle: String {
        if isNoteEditorExpanded {
            return "הסתר שדה הערה"
        }
        return trimmedNote == nil ? "הוסף הערה (אופציונלי)" : "ערוך או מחק את ההערה"
    }

    private enum Field: Hashable {
        case search
        case note
    }

    private var isSplitTransaction: Bool {
        transaction.notes?.contains("[SPLIT]") == true
    }

    private var splitReferenceText: String? {
        guard let notes = transaction.notes else { return nil }
        guard let range = notes.range(of: "[SPLIT]") else { return nil }
        let snippet = notes[range.upperBound...].trimmingCharacters(in: .whitespacesAndNewlines)
        return snippet.isEmpty ? nil : snippet
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .trailing, spacing: 16) {
                    headerSection
                    actionButtons
                    categoryPickerSection
                    noteEditorSection
                    confirmSection
                    splitSection
                    Button(role: .destructive) {
                        dismiss()
                        onDelete()
                    } label: {
                        HStack {
                            Image(systemName: "trash")
                            Text("מחק עסקה")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red.opacity(0.1))
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }

                    Button {
                        showHideConfirmation = true
                    } label: {
                        VStack(alignment: .trailing, spacing: 6) {
                            HStack {
                                Image(systemName: "eye.slash.fill")
                                Text("הסתר עסקאות של בית העסק")
                            }
                            .font(.body.weight(.semibold))
                            Text("לא תראה יותר חיובים מ-\(transaction.business_name ?? "בית העסק") במסך זה.")
                                .font(.footnote)
                                .foregroundColor(.secondary)
                                .multilineTextAlignment(.trailing)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.orange.opacity(0.12))
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                    .buttonStyle(.plain)
                }
                .padding()
            }
            .scrollIndicators(.hidden)
            .navigationTitle("החלפת קטגוריה")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden(true) // Hide default back button to avoid constraint conflicts
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.body.weight(.semibold))
                    }
                    .accessibilityLabel("סגור")
                }
            }
        }
        .contentShape(Rectangle())
        .simultaneousGesture(
            TapGesture().onEnded {
                dismissKeyboardIfNeeded()
            }
        )
        .environment(\.layoutDirection, .rightToLeft)
        .confirmationDialog(
            "להחיל קטגוריה עתידית?",
            isPresented: $showFutureChoice,
            presenting: pendingCategory
        ) { selection in
            Button("שנה רק לעסקה זו") {
                dismiss()
                onSelect(selection, trimmedNote)
                pendingCategory = nil
                noteText = ""
            }
            Button("שמור לכל העסקאות העתידיות") {
                dismiss()
                onSelectForFuture(selection, trimmedNote)
                pendingCategory = nil
                noteText = ""
            }
            Button("בטל", role: .cancel) {
                pendingCategory = nil
            }
        } message: { selection in
            Text("האם לעדכן רק את העסקה הזו או להחיל את \(selection) על עסקאות עתידיות של \(transaction.business_name ?? "בית העסק")?")
        }
        .alert("להסתיר עסקאות מבית העסק?", isPresented: $showHideConfirmation) {
            Button("הסתר", role: .destructive) {
                dismiss()
                onHideBusiness()
            }
            Button("בטל", role: .cancel) { }
        } message: {
            Text("נוסיף את \(transaction.business_name ?? "בית העסק") לרשימת בתי העסק הנסתרים, כדי שעסקאות עתידיות ממנו לא יוצגו במסך האישור.")
        }
        .sheet(isPresented: $showSplitSheet) {
            SplitTransactionSheet(
                transaction: transaction,
                availableCategories: categories.map(\.name),
                onSubmit: { originalTransactionId, splits in
                    // Create safe copies of the values to ensure they're valid
                    let safeId = String(originalTransactionId)
                    let safeSplits = Array(splits) // Ensure we have a copy of the array
                    handleSplitSubmission(originalTransactionId: safeId, splits: safeSplits)
                },
                onSuccess: {
                    showSplitSheet = false
                    dismiss()
                }
            )
        }
        .onAppear {
            if startWithSplit {
                DispatchQueue.main.async {
                    showSplitSheet = true
                }
            }
        }
    }

    private func dismissKeyboardIfNeeded() {
        guard focusedField != nil else { return }
        focusedField = nil
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }

    @ViewBuilder
    private var splitSection: some View {
        if isSplitTransaction {
            VStack(alignment: .trailing, spacing: 8) {
                HStack {
                    Image(systemName: "arrow.triangle.branch")
                        .foregroundColor(.accentColor)
                    Text("העסקה כבר פוצלה")
                        .font(.body.weight(.semibold))
                }
                .frame(maxWidth: .infinity, alignment: .trailing)

                if let snippet = splitReferenceText {
                    Text(snippet)
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.trailing)
                        .frame(maxWidth: .infinity, alignment: .trailing)
                } else if let note = transaction.notes {
                    Text(note)
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.trailing)
                        .frame(maxWidth: .infinity, alignment: .trailing)
                }

                Text("תוכל למצוא את שתי העסקאות הנפרדות במסך הדוחות או לבטל את הפיצול מהדפדפן.")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.trailing)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(Color(UIColor.systemGray5))
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        } else {
            Button {
                dismissKeyboardIfNeeded()
                showSplitSheet = true
            } label: {
                VStack(alignment: .trailing, spacing: 6) {
                    HStack {
                        Image(systemName: "square.split.2x2")
                            .font(.body.weight(.semibold))
                        Text("פצל עסקה")
                            .font(.body.weight(.semibold))
                    }
                    .frame(maxWidth: .infinity, alignment: .trailing)
                    Text("חלק את החיוב למספר קטגוריות וחודשיםabelle.")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.trailing)
                    Text("הסכום הכולל נשמר ומועבר לקטגוריות שונות בהתאם לשדות שתזין.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.trailing)
                }
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding()
                .background(Color.accentColor.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                .shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: 6)
            }
            .buttonStyle(.plain)
        }
    }

    private func toggleCategoryPicker() {
        withAnimation(.spring(response: 0.3, dampingFraction: 0.85, blendDuration: 0.2)) {
            isCategoryPickerExpanded.toggle()
            if !isCategoryPickerExpanded {
                dismissKeyboardIfNeeded()
            }
        }
    }

    private func toggleNoteEditor() {
        withAnimation(.spring(response: 0.3, dampingFraction: 0.85, blendDuration: 0.2)) {
            isNoteEditorExpanded.toggle()
        }
        if isNoteEditorExpanded {
            DispatchQueue.main.async {
                focusedField = .note
            }
        } else {
            dismissKeyboardIfNeeded()
        }
    }

    private func presentCategoryConfirmation() {
        guard pendingCategory != nil else { return }
        dismissKeyboardIfNeeded()
        DispatchQueue.main.async {
            showFutureChoice = true
        }
    }

    @ViewBuilder
    private var headerSection: some View {
        VStack(alignment: .trailing, spacing: 4) {
            Text(transaction.business_name ?? "ללא שם")
                .font(.headline)
            Text("בחר קטגוריה חדשה לעסקה זו.")
                .font(.footnote)
                .foregroundColor(.secondary)
        }
    }

    @ViewBuilder
    private var actionButtons: some View {
        ActionButton(
            title: "שנה קטגוריה",
            subtitle: isCategoryPickerExpanded ? "הסתר רשימת קטגוריות" : "הצג רשימת קטגוריות",
            systemImage: "slider.horizontal.3",
            isActive: isCategoryPickerExpanded
        ) {
            toggleCategoryPicker()
        }
        ActionButton(
            title: trimmedNote ?? "הוסף הערה",
            subtitle: noteButtonSubtitle,
            systemImage: "square.and.pencil",
            isActive: isNoteEditorExpanded || trimmedNote != nil
        ) {
            toggleNoteEditor()
        }
    }

    @ViewBuilder
    private var categoryPickerSection: some View {
        if isCategoryPickerExpanded {
            VStack(alignment: .trailing, spacing: 12) {
                TextField("חפש קטגוריה", text: $searchText)
                    .textFieldStyle(.roundedBorder)
                    .textInputAutocapitalization(.never)
                    .disableAutocorrection(true)
                    .multilineTextAlignment(.trailing)
                    .focused($focusedField, equals: .search)
                if categories.isEmpty {
                    VStack(spacing: 8) {
                        ProgressView()
                        Text("טוען קטגוריות זמינות...")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 40)
                } else {
                    ScrollView {
                        LazyVStack(alignment: .trailing, spacing: 12) {
                            ForEach(filteredCategories) { category in
                                let isSelected = pendingCategory == category.name
                                Button {
                                    withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) {
                                        pendingCategory = category.name
                                    }
                                } label: {
                                    HStack {
                                        Image(systemName: isSelected ? "checkmark.circle.fill" : "arrowshape.left.fill")
                                            .foregroundColor(isSelected ? .accentColor : .secondary)
                                        Spacer()
                                        Text(category.name)
                                            .font(.body.weight(.medium))
                                    }
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(
                                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                                            .fill(isSelected ? Color.accentColor.opacity(0.15) : Color(UIColor.systemGray5))
                                    )
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                                            .stroke(isSelected ? Color.accentColor.opacity(0.6) : .clear, lineWidth: 1.5)
                                    )
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                    .frame(maxHeight: 260)
                }
            }
            .padding()
            .background(Color.cardBackground)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .transition(.opacity.combined(with: .move(edge: .top)))
        }
    }

    @ViewBuilder
    private var noteEditorSection: some View {
        if isNoteEditorExpanded {
            VStack(alignment: .trailing, spacing: 8) {
                Text("הוסף הערה (אופציונלי)")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity, alignment: .trailing)
                ZStack(alignment: .topTrailing) {
                    if trimmedNote == nil {
                        Text("לדוגמה: בדיקה מול הנה\"ח")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                            .padding(.top, 18)
                            .padding(.horizontal, 18)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                    }
                    TextEditor(text: $noteText)
                        .frame(minHeight: 110, maxHeight: 160)
                        .padding(12)
                        .background(Color.clear)
                        .multilineTextAlignment(.trailing)
                        .focused($focusedField, equals: .note)
                }
                .background(Color(UIColor.systemGray5))
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            .padding()
            .background(Color.cardBackground)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .transition(.opacity.combined(with: .move(edge: .top)))
        }
    }

    @ViewBuilder
    private var confirmSection: some View {
        VStack(alignment: .trailing, spacing: 10) {
            HStack {
                if let pendingCategory {
                    Text(pendingCategory)
                        .font(.body.weight(.semibold))
                        .foregroundColor(.accentColor)
                        .lineLimit(1)
                        .truncationMode(.tail)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color.accentColor.opacity(0.15))
                        .clipShape(Capsule())
                } else {
                    Text("בחר קטגוריה ואז אשר את השינוי")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }
                Spacer(minLength: 0)
            }
            .frame(maxWidth: .infinity, alignment: .trailing)

            Button {
                presentCategoryConfirmation()
            } label: {
                Text("אשר שינוי קטגוריה")
                    .font(.body.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(pendingCategory == nil ? Color(UIColor.systemGray5) : Color.accentColor.opacity(0.2))
                    .foregroundColor(pendingCategory == nil ? .secondary : .accentColor)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            .buttonStyle(.plain)
            .disabled(pendingCategory == nil)

            if pendingCategory != nil {
                Button(role: .cancel) {
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) {
                        pendingCategory = nil
                    }
                } label: {
                    Text("נקה בחירה")
                        .font(.footnote.weight(.semibold))
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity)
                }
            }
        }
        .padding()
        .background(Color.cardBackground)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private func handleSplitSubmission(originalTransactionId: String, splits: [SplitTransactionEntry]) {
        // Add safety checks before accessing the parameters
        guard !originalTransactionId.isEmpty else {
            print("❌ [SPLIT DEBUG] Original transaction ID is empty")
            return
        }

        guard !splits.isEmpty else {
            print("❌ [SPLIT DEBUG] Splits array is empty")
            return
        }

        // Test safe access to the parameters before logging
        let safeId = originalTransactionId

        logSplitReception(originalTransactionId: safeId, splits: splits)
        onSplit(safeId, splits)
    }

    private func logSplitReception(originalTransactionId: String, splits: [SplitTransactionEntry]) {
        // Safe logging by accessing values first
        let safeId = String(originalTransactionId)
        let safeSplitsCount = splits.count
        print("🔍 [SPLIT DEBUG] onSubmit received data — id:", safeId, "splits:", safeSplitsCount)

        if safeSplitsCount > 0 {
            let safePreview = Array(splits.prefix(3)) // Convert to Array for safety
            for (index, entry) in safePreview.enumerated() {
                // Access properties safely
                let amount = entry.amount
                let category = String(entry.category)
                let flowMonth = String(entry.flowMonth)
                print("    ↳ Split #", index, "amount=", amount, "category=", category, "flow_month=", flowMonth)
            }
            if safeSplitsCount > safePreview.count {
                print("    … ועוד", safeSplitsCount - safePreview.count, "פיצולים")
            }
        }
    }
}

private struct NoteEntrySheet: View {
    let transaction: Transaction
    let isSaving: Bool
    var onSave: (String) async -> Bool

    @Environment(\.dismiss) private var dismiss
    @State private var noteText: String

    init(transaction: Transaction, isSaving: Bool, onSave: @escaping (String) async -> Bool) {
        self.transaction = transaction
        self.isSaving = isSaving
        self.onSave = onSave
        self._noteText = State(initialValue: transaction.notes ?? "")
    }

    var body: some View {
        NavigationStack {
            VStack(alignment: .trailing, spacing: 16) {
                VStack(alignment: .trailing, spacing: 4) {
                    Text("הערה לעסקה")
                        .font(.headline)
                    Text(transaction.business_name ?? "עסקה ממתינה")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity, alignment: .trailing)

                ZStack(alignment: .topTrailing) {
                    if noteText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        Text("לדוגמה: טלפון לשליח, בדיקת חשבונית")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                            .padding(.horizontal, 12)
                            .padding(.top, 14)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                    }
                    TextEditor(text: $noteText)
                        .frame(minHeight: 160)
                        .padding(12)
                        .background(Color(UIColor.systemGray5))
                        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                        .multilineTextAlignment(.trailing)
                }

                Spacer()

                Button {
                    let trimmed = noteText.trimmingCharacters(in: .whitespacesAndNewlines)
                    let dismissAction = dismiss
                    Task { @MainActor in
                        let saved = await onSave(trimmed)
                        if saved {
                            dismissAction()
                        }
                    }
                } label: {
                    HStack {
                        if isSaving {
                            ProgressView()
                                .progressViewStyle(.circular)
                        }
                        Text(isSaving ? "שומר..." : "שמור הערה")
                            .font(.body.weight(.semibold))
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.accentColor.opacity(0.18))
                    .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                }
                .disabled(isSaving)
            }
            .padding()
            .navigationTitle("הוספת הערה")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("ביטול") {
                        dismiss()
                    }
                }
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
    }
}

private struct ActionButton: View {
    var title: String
    var subtitle: String
    var systemImage: String
    var isActive: Bool
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                VStack(alignment: .trailing, spacing: 4) {
                    Text(title)
                        .font(.body.weight(.semibold))
                        .multilineTextAlignment(.trailing)
                        .lineLimit(1)
                        .truncationMode(.tail)
                    Text(subtitle)
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.trailing)
                        .lineLimit(1)
                        .truncationMode(.tail)
                }
                Spacer(minLength: 0)
                Image(systemName: systemImage)
                    .font(.body.weight(.semibold))
                    .foregroundColor(isActive ? .accentColor : .secondary)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(isActive ? Color.accentColor.opacity(0.12) : Color(UIColor.systemGray5))
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .shadow(color: Color.black.opacity(0.06), radius: 8, x: 0, y: 4)
        }
        .buttonStyle(.plain)
    }
}
