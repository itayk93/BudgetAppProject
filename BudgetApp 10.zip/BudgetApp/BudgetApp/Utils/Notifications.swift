import Foundation

extension Notification.Name {
    static let authChanged = Notification.Name("auth.changed")
}

