import SwiftUI
import UIKit

struct PendingTransactionsReviewView: View {
    @StateObject private var viewModel = PendingTransactionsReviewViewModel()
    @State private var dragOffset: CGSize = .zero
    @State private var pendingCategoryChange: Transaction?
    @State private var toastMessage: String?
    @State private var initialBatchCount: Int = 0
    @Environment(\.layoutDirection) private var layoutDirection
    @Environment(\.dismiss) private var dismiss

    private let swipeThreshold: CGFloat = 110
    private let cardMaxWidth: CGFloat = 420
    private let maxVisibleCards: Int = 3

    private var currentTransaction: Transaction? {
        viewModel.transactions.first
    }

    private var shouldShowActionBar: Bool {
        currentTransaction != nil && pendingCategoryChange == nil
    }

    private var actionButtonDisabled: Bool {
        viewModel.processingTransactionID != nil
    }

    private var remainingTasksText: String {
        guard initialBatchCount > 0 else { return "" }
        let remaining = viewModel.transactions.count - 1
        if remaining <= 0 {
            return "עסקה אחרונה להיום"
        }
        return "נשארו עוד \(remaining) משימות"
    }

    private var completionProgress: Double {
        guard initialBatchCount > 0 else { return 0 }
        let remaining = Double(max(min(viewModel.transactions.count, initialBatchCount), 0))
        return max(0, min(1, 1 - (remaining / Double(initialBatchCount))))
    }

    private var completionPercentageText: String {
        let percentage = Int(round(completionProgress * 100))
        return "\(percentage)%"
    }

    private var normalizedDragWidth: CGFloat {
        layoutDirection == .rightToLeft ? -dragOffset.width : dragOffset.width
    }

    private var directionalOffset: CGSize {
        layoutDirection == .rightToLeft
        ? CGSize(width: -dragOffset.width, height: dragOffset.height)
        : dragOffset
    }

    private var headerTitle: String {
        if viewModel.loading && viewModel.transactions.isEmpty {
            return "טוענים עסקאות..."
        }
        return viewModel.transactions.isEmpty ? "הכל נקי להיום" : "סקור \(viewModel.transactions.count) טרנזקציות ממתינות"
    }

    private var headerSubtitle: String {
        if viewModel.loading && viewModel.transactions.isEmpty {
            return "מתחברים ל-Supabase ומביאים את התנועות האחרונות מהבנק."
        }
        return "נסרקו ב-48 השעות האחרונות ומחכות שתעברו עליהן במהירות."
    }

    var body: some View {
        ZStack(alignment: .bottom) {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .trailing, spacing: 28) {
                    heroSection
                    header
                    deckView
                    swipeLegend
                    statusSection
                    Spacer().frame(height: shouldShowActionBar ? 220 : 40)
                }
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(.horizontal, 20)
                .padding(.top, 18)
                .padding(.bottom, 12)
            }
            if let currentTransaction, shouldShowActionBar {
                actionBar(for: currentTransaction)
                    .transition(.move(edge: .bottom).combined(with: .opacity))
                    .padding(.horizontal, 20)
                    .padding(.bottom, 12)
            }
        }
        .background(Color.groupedBackground.ignoresSafeArea())
        .navigationTitle("אישור עסקאות")
        .navigationBarTitleDisplayMode(.inline)
        .task {
            print("📱 [DEBUG] View loaded, starting refresh...")
            await viewModel.refresh()
        }
        .refreshable {
            print("📱 [DEBUG] Pull to refresh triggered")
            await viewModel.refresh()
        }
        .sheet(item: $pendingCategoryChange) { transaction in
            CategorySelectionSheet(
                transaction: transaction,
                categories: viewModel.categories,
                onSelect: { category, note in
                    Task {
                        await viewModel.reassign(transaction, to: category, note: note)
                    }
                },
                onSelectForFuture: { category, note in
                    Task {
                        await viewModel.reassignForFuture(transaction, to: category, note: note)
                    }
                },
                onDelete: {
                    Task {
                        await viewModel.delete(transaction)
                    }
                },
                onHideBusiness: {
                    Task {
                        await viewModel.hideBusiness(transaction)
                    }
                },
                onSplit: { originalTransactionId, splits in
                    Task {
                        do {
                            try await viewModel.splitTransaction(
                                transaction,
                                originalTransactionId: originalTransactionId,
                                splits: splits
                            )
                        } catch {
                            // Handle error appropriately
                            print("❌ splitTransaction failed:", error)
                        }
                    }
                }
            )
        }
        .overlay(alignment: .top) {
            if let toastMessage {
                toastView(message: toastMessage)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .padding(.top, 12)
                    .padding(.horizontal, 24)
            }
        }
        .onChange(of: viewModel.actionMessage) { _, newValue in
            guard let newValue else { return }
            toastMessage = newValue
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.4) {
                if toastMessage == newValue {
                    withAnimation {
                        toastMessage = nil
                    }
                    viewModel.actionMessage = nil
                }
            }
        }
        .onChange(of: viewModel.transactions.count) { _, newValue in
            if newValue == 0 {
                initialBatchCount = 0
            } else if newValue > initialBatchCount {
                initialBatchCount = newValue
            } else if initialBatchCount == 0 {
                initialBatchCount = newValue
            }
        }
        .environment(\.layoutDirection, .rightToLeft)
    }

    @ViewBuilder
    private var heroSection: some View {
        if let transaction = currentTransaction {
            heroCardView(transaction)
        } else if viewModel.loading {
            heroLoadingPlaceholder
        } else {
            heroEmptyState
        }
    }

    private func heroCardView(_ transaction: Transaction) -> some View {
        VStack(spacing: 0) {
            VStack(alignment: .trailing, spacing: 10) {
                HStack {
                    Spacer()
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(.white)
                            .frame(width: 32, height: 32)
                            .background(Color.black.opacity(0.25))
                            .clipShape(Circle())
                    }
                }
                Text("הוצאות משתנות")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(.white)
                    .multilineTextAlignment(.trailing)
                    .frame(maxWidth: .infinity, alignment: .trailing)
        Text("\(currencySymbol(for: transaction.currency))\(heroAmountText(transaction.absoluteAmount))")
                    .font(.system(size: 42, weight: .bold))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.trailing)
                    .frame(maxWidth: .infinity, alignment: .trailing)
                VStack(alignment: .trailing, spacing: 4) {
                    Text(transaction.business_name ?? transaction.payment_method ?? "עסקה ממתינה")
                        .font(.headline)
                        .foregroundColor(.white.opacity(0.95))
                        .frame(maxWidth: .infinity, alignment: .trailing)
                    Text(transaction.payment_method ?? "כרטיס • \(String(transaction.id.suffix(4)))")
                        .font(.footnote)
                        .foregroundColor(.white.opacity(0.85))
                        .frame(maxWidth: .infinity, alignment: .trailing)
                    Text(formattedPaymentDate(for: transaction))
                        .font(.caption2)
                        .foregroundColor(.white.opacity(0.75))
                        .frame(maxWidth: .infinity, alignment: .trailing)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            .frame(maxWidth: .infinity, alignment: .trailing)
            .padding(.horizontal, 24)
            .padding(.top, 20)
            .padding(.bottom, 16)
            .background(heroYellowColor)

            VStack(spacing: 12) {
                ForEach(heroActions(for: transaction)) { action in
                    heroActionButton(action)
                }
                if viewModel.transactions.count > 1 {
                    Text("נותרו עוד \(viewModel.transactions.count - 1) טרנזקציות ממתינות")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity, alignment: .trailing)
                }
            }
            .padding(.horizontal, 12)
            .padding(.top, 18)
            .padding(.bottom, 20)
        }
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 32, style: .continuous))
        .shadow(color: Color.black.opacity(0.08), radius: 16, x: 0, y: 8)
        .padding(.horizontal, 20)
        .offset(directionalOffset)
        .rotationEffect(.degrees(Double(normalizedDragWidth / 10)))
        .animation(.interactiveSpring(), value: dragOffset)
        .gesture(
            DragGesture(minimumDistance: 8)
                .onChanged { value in
                    guard viewModel.processingTransactionID == nil && pendingCategoryChange == nil else { return }
                    dragOffset = value.translation
                }
                .onEnded { value in
                    guard viewModel.processingTransactionID == nil && pendingCategoryChange == nil else { return }
                    handleDragEnd(value: value, transaction: transaction)
                }
        )
        .simultaneousGesture(
            TapGesture().onEnded {
                guard viewModel.processingTransactionID == nil && pendingCategoryChange == nil else { return }
                pendingCategoryChange = transaction
            }
        )
        .allowsHitTesting(viewModel.processingTransactionID == nil && pendingCategoryChange == nil)
    }

    private func heroActionButton(_ action: HeroAction) -> some View {
        Button {
            action.action()
        } label: {
            HStack(spacing: 12) {
                Text(action.title)
                    .font(.body.weight(.semibold))
                    .foregroundColor(.primary)
                Spacer()
                Image(systemName: action.icon)
                    .font(.title3)
                    .foregroundColor(.secondary)
            }
            .frame(maxWidth: .infinity, alignment: .trailing)
            .padding()
            .background(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(Color(UIColor.systemGray6))
                    .shadow(color: Color.black.opacity(0.06), radius: 6, x: 0, y: 3)
            )
        }
        .buttonStyle(.plain)
    }

    private func heroActions(for transaction: Transaction) -> [HeroAction] {
        [
            HeroAction(id: "note", icon: "text.bubble", title: "להוסיף הערה") {
                showToastMessage("הערה תתואם בקרוב למסך זה.")
            },
            HeroAction(id: "move", icon: "arrowshape.turn.up.right", title: "להזיז את ההוצאה") {
                pendingCategoryChange = transaction
            },
            HeroAction(id: "split", icon: "scissors", title: "לפצל את ההוצאה") {
                showToastMessage("שדה הפיצול יתווסף בקרוב.")
            },
            HeroAction(id: "savings", icon: "banknote", title: "זה הפקדה לחיסכון!") {
                showToastMessage("סומן כהפקדה לחיסכון.")
            }
        ]
    }

    private var heroLoadingPlaceholder: some View {
        VStack(spacing: 12) {
            ProgressView()
                .progressViewStyle(CircularProgressViewStyle(tint: .accentColor))
            Text("טוען עסקאות ממתינות...")
                .font(.footnote)
                .foregroundColor(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(24)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .shadow(color: Color.black.opacity(0.08), radius: 12, x: 0, y: 6)
        .padding(.horizontal, 20)
    }

    private var heroEmptyState: some View {
        VStack(spacing: 8) {
            Text("אין טרנזקציות ממתינות")
                .font(.headline)
            Text("רענן את המסך כדי לבדוק אם הגיעו עסקאות חדשות.")
                .font(.footnote)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(24)
        .background(Color.white)
        .clipShape(RoundedRectangle(cornerRadius: 28, style: .continuous))
        .shadow(color: Color.black.opacity(0.08), radius: 12, x: 0, y: 6)
        .padding(.horizontal, 20)
    }

    private func heroAmountText(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.locale = Locale(identifier: "he_IL")
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = value.truncatingRemainder(dividingBy: 1) == 0 ? 0 : 1
        formatter.minimumFractionDigits = 0
        return formatter.string(from: NSNumber(value: value)) ?? "0"
    }

    private func formattedPaymentDate(for transaction: Transaction) -> String {
        guard let date = transaction.parsedDate else {
            return "תאריך לא זמין"
        }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "he_IL")
        formatter.dateStyle = .short
        formatter.timeStyle = .none
        return formatter.string(from: date)
    }

    private func currencySymbol(for code: String?) -> String {
        guard let code else { return "₪" }
        let formatter = NumberFormatter()
        formatter.locale = Locale(identifier: "he_IL")
        formatter.numberStyle = .currency
        formatter.currencyCode = code
        return formatter.currencySymbol ?? "₪"
    }

    private func showToastMessage(_ message: String) {
        toastMessage = message
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.4) {
            if toastMessage == message {
                withAnimation {
                    toastMessage = nil
                }
            }
        }
    }

    private var heroYellowColor: Color {
        Color(red: 241/255, green: 193/255, blue: 26/255)
    }

    @ViewBuilder
    private var header: some View {
        VStack(alignment: .trailing, spacing: 16) {
            HStack(alignment: .top, spacing: 16) {
                Spacer(minLength: 0)
                VStack(alignment: .trailing, spacing: 6) {
                    Text(headerTitle)
                        .font(.title3.weight(.semibold))
                        .multilineTextAlignment(.trailing)
                    Text(headerSubtitle)
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.trailing)
                }
                statusBadge
            }
            progressMeter
            Button {
                Task { await viewModel.refresh() }
            } label: {
                Label("רענון הרשימה", systemImage: "arrow.clockwise")
                    .labelStyle(.titleAndIcon)
                    .font(.footnote.weight(.medium))
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.small)
            .tint(.accentColor.opacity(0.18))
            .frame(maxWidth: .infinity, alignment: .trailing)
        }
        .frame(maxWidth: .infinity, alignment: .trailing)
    }

    private var statusBadge: some View {
        let badgeTitle = viewModel.transactions.isEmpty
        ? (viewModel.loading ? "מתעדכן" : "מעודכן")
        : "\(viewModel.transactions.count) ממתינות"
        return Text(badgeTitle)
            .font(.caption.weight(.semibold))
            .foregroundColor(.accentColor)
            .padding(.horizontal, 14)
            .padding(.vertical, 6)
            .background(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(Color.accentColor.opacity(0.12))
            )
    }

    private var progressMeter: some View {
        VStack(alignment: .trailing, spacing: 6) {
            HStack(spacing: 8) {
                Image(systemName: "sparkles")
                    .font(.caption.weight(.bold))
                    .foregroundColor(.accentColor)
                Text("התקדמות באישור")
                    .font(.caption.weight(.medium))
                    .foregroundColor(.secondary)
                Text(completionPercentageText)
                    .font(.caption.weight(.bold))
                    .foregroundColor(.primary)
            }
            RTLProgressBar(progress: completionProgress, tint: .accentColor)
                .frame(height: 8)
        }
    }

    private var swipeLegend: some View {
        VStack(alignment: .trailing, spacing: 12) {
            Text("זכרו: החלקה מהירה ימינה מאשרת את העסקה, שמאלה פותחת עריכה.")
                .font(.footnote)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.trailing)
            HStack(spacing: 12) {
                legendPill(text: "לאשר", systemImage: "hand.thumbsup.fill", color: .green)
                legendPill(text: "לערוך קטגוריה", systemImage: "slider.horizontal.3", color: .orange)
            }
        }
        .padding(18)
        .background(Material.ultraThin)
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))
    }

    @ViewBuilder
    private var deckView: some View {
        if let error = viewModel.errorMessage {
            infoCard(
                icon: "exclamationmark.triangle.fill",
                title: "משהו השתבש",
                message: error,
                tint: .orange
            ) {
                Task { await viewModel.refresh() }
            }
        } else if viewModel.loading && viewModel.transactions.isEmpty {
            infoCard(
                icon: "arrow.triangle.2.circlepath",
                title: "טוענים עסקאות",
                message: "מתחברים אל Supabase כדי להביא את העסקאות מ-48 השעות האחרונות.",
                tint: .accentColor
            )
        } else if viewModel.transactions.isEmpty {
            celebrationCard
        } else {
            ZStack {
                let remainingTransactions = Array(viewModel.transactions.dropFirst())
                let visibleCount = max(maxVisibleCards - 1, 0)
                let visibleTransactions = Array(remainingTransactions.prefix(visibleCount))
                ForEach(Array(visibleTransactions.enumerated()), id: \.element.id) { index, transaction in
                    let theme = transactionCardTheme(for: transaction)
                    SwipeableTransactionCard(
                        transaction: transaction,
                        isTopCard: index == 0,
                        dragOffset: .zero,
                        theme: theme,
                        baseRotation: stackRotation(for: index)
                    )
                    .padding(.horizontal, 4)
                    .offset(y: stackOffset(for: index))
                    .scaleEffect(stackScale(for: index))
                    .shadow(color: Color.black.opacity(0.08 + Double(index) * 0.03), radius: 22, x: 0, y: Double(8 + index * 4))
                    .opacity(viewModel.processingTransactionID == transaction.id ? 0.35 : 1)
                    .zIndex(Double(maxVisibleCards - index))
                }
                if viewModel.loading {
                    VStack(spacing: 8) {
                        ProgressView()
                        Text("מביא חדשות...")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding(12)
                    .background(Material.ultraThin)
                    .clipShape(Capsule())
                    .offset(y: -190)
                    .transition(.opacity)
                }
            }
            .frame(height: 400)
            .frame(maxWidth: cardMaxWidth)
            .frame(maxWidth: .infinity, alignment: .center)
        }
    }

    @ViewBuilder
    private var statusSection: some View {
        if let transaction = currentTransaction {
            VStack(alignment: .trailing, spacing: 8) {
                Text(nextStepMessage(for: transaction))
                    .font(.headline)
                    .foregroundColor(.primary)
                Text(supportingStatusText(for: transaction))
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
            .multilineTextAlignment(.trailing)
            .frame(maxWidth: .infinity, alignment: .trailing)
            .padding(20)
            .background(
                RoundedRectangle(cornerRadius: 26, style: .continuous)
                    .fill(Color.cardBackground)
                    .shadow(color: Color.black.opacity(0.04), radius: 14, x: 0, y: 8)
            )
        } else if !viewModel.loading {
            Text("כרגע אין עסקאות ממתינות. ברגע שיתווספו חדשות תופיע כאן רשימת המשימות.")
                .font(.footnote)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.trailing)
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(20)
                .background(
                    RoundedRectangle(cornerRadius: 26, style: .continuous)
                        .fill(Material.ultraThin)
                )
        }
    }

    private func actionBar(for transaction: Transaction) -> some View {
        VStack(alignment: .trailing, spacing: 16) {
            HStack(spacing: 12) {
                Button {
                    Task { await viewModel.approve(transaction) }
                } label: {
                    Label("להמשיך", systemImage: "checkmark.circle.fill")
                        .labelStyle(.titleAndIcon)
                        .font(.body.weight(.semibold))
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(transaction.isIncome ? Color.green : Color.accentColor)
                .disabled(actionButtonDisabled)

                Button {
                    pendingCategoryChange = transaction
                } label: {
                    Label("לערוך", systemImage: "slider.horizontal.3")
                        .labelStyle(.titleAndIcon)
                        .font(.body.weight(.semibold))
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(Color.secondary.opacity(0.2))
                .disabled(actionButtonDisabled)
            }
        }
        .padding(20)
        .background(
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .fill(Material.ultraThin)
        )
    }

    private func infoCard(icon: String, title: String, message: String, tint: Color, retry: (() -> Void)? = nil) -> some View {
        VStack(alignment: .trailing, spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 34))
                .foregroundColor(tint)
                .frame(maxWidth: .infinity, alignment: .trailing)
            Text(title)
                .font(.headline)
            Text(message)
                .font(.footnote)
                .foregroundColor(.secondary)
                .multilineTextAlignment(.trailing)
            if let retry {
                Button("נסה שוב") { retry() }
                    .buttonStyle(.borderedProminent)
                    .controlSize(.small)
                    .tint(tint.opacity(0.2))
            }
        }
        .frame(maxWidth: cardMaxWidth)
        .padding(26)
        .background(
            RoundedRectangle(cornerRadius: 28, style: .continuous)
                .fill(Color.cardBackground)
        )
        .shadow(color: Color.black.opacity(0.04), radius: 16, x: 0, y: 12)
        .frame(maxWidth: .infinity, alignment: .center)
    }

    private var celebrationCard: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 32, style: .continuous)
                .fill(LinearGradient(colors: [
                    Color(red: 1.0, green: 0.95, blue: 0.82),
                    Color(red: 1.0, green: 0.98, blue: 0.9)
                ], startPoint: .top, endPoint: .bottom))
            ForEach(0..<6) { index in
                Capsule()
                    .fill(Color.yellow.opacity(0.35))
                    .frame(width: 40, height: 220)
                    .rotationEffect(.degrees(Double(index) * 30))
            }
            VStack(alignment: .trailing, spacing: 12) {
                Image(systemName: "checkmark.seal.fill")
                    .font(.system(size: 54))
                    .foregroundColor(.accentColor)
                Text("סיימנו להיום")
                    .font(.title3.weight(.bold))
                Text("אין עסקאות ממתינות כרגע. נעדכן מיד כשהבנק יסיים לסנכרן תנועות חדשות.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.trailing)
                Button {
                    Task { await viewModel.refresh() }
                } label: {
                    Text("בדקו שוב מאוחר יותר")
                        .font(.footnote.weight(.medium))
                        .padding(.vertical, 10)
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(.accentColor.opacity(0.2))
            }
            .padding(30)
        }
        .frame(height: 360)
        .frame(maxWidth: cardMaxWidth)
        .frame(maxWidth: .infinity, alignment: .center)
    }

    private func stackOffset(for index: Int) -> CGFloat {
        CGFloat(index * 26)
    }

    private func stackScale(for index: Int) -> CGFloat {
        max(0.85, 1 - CGFloat(index) * 0.05)
    }

    private func stackRotation(for index: Int) -> Double {
        index == 0 ? 0 : Double(index) * -4
    }

    private func transactionCardTheme(for transaction: Transaction) -> TransactionCardTheme {
        if transaction.isIncome {
            return TransactionCardTheme(
                topColor: Color(red: 0.9, green: 0.96, blue: 0.84),
                bottomColor: Color(red: 0.99, green: 0.96, blue: 0.9),
                accent: Color(red: 0.2, green: 0.55, blue: 0.3),
                accentSoft: Color(red: 0.78, green: 0.9, blue: 0.72),
                symbol: "arrow.down.circle.fill"
            )
        } else {
            return TransactionCardTheme(
                topColor: Color(red: 0.88, green: 0.93, blue: 1.0),
                bottomColor: Color(red: 0.95, green: 0.98, blue: 1.0),
                accent: Color(red: 0.2, green: 0.35, blue: 0.74),
                accentSoft: Color(red: 0.76, green: 0.85, blue: 1.0),
                symbol: "arrow.up.circle.fill"
            )
        }
    }

    private func legendPill(text: String, systemImage: String, color: Color) -> some View {
        HStack(spacing: 8) {
            Image(systemName: systemImage)
                .font(.footnote.weight(.bold))
            Text(text).font(.footnote)
        }
        .padding(.vertical, 6)
        .padding(.horizontal, 12)
        .background(color.opacity(0.12))
        .clipShape(Capsule())
    }

    private func handleDragEnd(value: DragGesture.Value, transaction: Transaction) {
        let translation = layoutDirection == .rightToLeft ? -value.translation.width : value.translation.width
        if translation > swipeThreshold {
            dragOffset = .zero
            Task { await viewModel.approve(transaction) }
        } else if translation < -swipeThreshold {
            dragOffset = .zero
            pendingCategoryChange = transaction
        } else {
            withAnimation(.spring()) {
                dragOffset = .zero
            }
        }
    }

    private func toastView(message: String) -> some View {
        HStack {
            Image(systemName: "checkmark")
                .foregroundColor(.white)
            Text(message)
                .font(.footnote)
                .foregroundColor(.white)
        }
        .padding(.vertical, 12)
        .padding(.horizontal, 18)
        .background(Color.black.opacity(0.8))
        .clipShape(Capsule())
    }

    private func nextStepMessage(for transaction: Transaction) -> String {
        let descriptor = transaction.isIncome ? "ההכנסה" : "ההוצאה"
        return "שימו את \(descriptor) הזו בקטגוריית \(categoryName(for: transaction))."
    }

    private func supportingStatusText(for transaction: Transaction) -> String {
        if let paymentMethod = transaction.payment_method, !paymentMethod.isEmpty {
            return "מקור העסקה: \(paymentMethod)."
        }
        if let paymentDate = transaction.parsedDate {
            let formatter = DateFormatter()
            formatter.locale = Locale(identifier: "he_IL")
            formatter.dateStyle = .medium
            return "תאריך העסקה: \(formatter.string(from: paymentDate))."
        }
        return "שייך ואשר כדי להמשיך לשאר המשימות."
    }

    private func categoryName(for transaction: Transaction) -> String {
        let trimmed = transaction.effectiveCategoryName.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.isEmpty {
            return transaction.isIncome ? "הכנסות" : "הוצאות"
        }
        return trimmed
    }
}

private struct TransactionCardTheme {
    let topColor: Color
    let bottomColor: Color
    let accent: Color
    let accentSoft: Color
    let symbol: String

    var gradient: LinearGradient {
        LinearGradient(colors: [topColor, bottomColor], startPoint: .top, endPoint: .bottom)
    }
}

private struct HeroAction: Identifiable {
    let id: String
    let icon: String
    let title: String
    let action: () -> Void
}

// The CategorySelectionSheet would be defined here as a private struct
private struct CategorySelectionSheet: View {
    let transaction: Transaction
    let categories: [TransactionCategory]
    var onSelect: (String, String?) -> Void
    var onSelectForFuture: (String, String?) -> Void
    var onDelete: () -> Void
    var onHideBusiness: () -> Void
    var onSplit: (String, [SplitTransactionEntry]) -> Void

    @State private var searchText: String = ""
    @State private var noteText: String = ""
    @State private var pendingCategory: String?
    @State private var showFutureChoice = false
    @State private var showHideConfirmation = false
    @State private var isCategoryPickerExpanded = false
    @State private var isNoteEditorExpanded = false
    @State private var showSplitSheet = false
    @FocusState private var focusedField: Field?
    @Environment(\.dismiss) private var dismiss

    private var trimmedSearchText: String {
        searchText.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private var filteredCategories: [TransactionCategory] {
        guard !trimmedSearchText.isEmpty else { return categories }
        return categories.filter { category in
            category.name.localizedCaseInsensitiveContains(trimmedSearchText)
        }
    }

    private var trimmedNote: String? {
        let trimmed = noteText.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }

    private var noteButtonSubtitle: String {
        if isNoteEditorExpanded {
            return "הסתר שדה הערה"
        }
        return trimmedNote == nil ? "הוסף הערה (אופציונלי)" : "ערוך או מחק את ההערה"
    }

    private enum Field: Hashable {
        case search
        case note
    }

    private var isSplitTransaction: Bool {
        transaction.notes?.contains("[SPLIT]") == true
    }

    private var splitReferenceText: String? {
        guard let notes = transaction.notes else { return nil }
        guard let range = notes.range(of: "[SPLIT]") else { return nil }
        let snippet = notes[range.upperBound...].trimmingCharacters(in: .whitespacesAndNewlines)
        return snippet.isEmpty ? nil : snippet
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .trailing, spacing: 16) {
                    headerSection
                    actionButtons
                    categoryPickerSection
                    noteEditorSection
                    confirmSection
                    splitSection
                    Button(role: .destructive) {
                        dismiss()
                        onDelete()
                    } label: {
                        HStack {
                            Image(systemName: "trash")
                            Text("מחק עסקה")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red.opacity(0.1))
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }

                    Button {
                        showHideConfirmation = true
                    } label: {
                        VStack(alignment: .trailing, spacing: 6) {
                            HStack {
                                Image(systemName: "eye.slash.fill")
                                Text("הסתר עסקאות של בית העסק")
                            }
                            .font(.body.weight(.semibold))
                            Text("לא תראה יותר חיובים מ-\(transaction.business_name ?? "בית העסק") במסך זה.")
                                .font(.footnote)
                                .foregroundColor(.secondary)
                                .multilineTextAlignment(.trailing)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.orange.opacity(0.12))
                        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                    }
                    .buttonStyle(.plain)
                }
                .padding()
            }
            .scrollIndicators(.hidden)
            .navigationTitle("החלפת קטגוריה")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarBackButtonHidden(true) // Hide default back button to avoid constraint conflicts
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button {
                        dismiss()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.body.weight(.semibold))
                    }
                    .accessibilityLabel("סגור")
                }
            }
        }
        .contentShape(Rectangle())
        .simultaneousGesture(
            TapGesture().onEnded {
                dismissKeyboardIfNeeded()
            }
        )
        .environment(\.layoutDirection, .rightToLeft)
        .confirmationDialog(
            "להחיל קטגוריה עתידית?",
            isPresented: $showFutureChoice,
            presenting: pendingCategory
        ) { selection in
            Button("שנה רק לעסקה זו") {
                dismiss()
                onSelect(selection, trimmedNote)
                pendingCategory = nil
                noteText = ""
            }
            Button("שמור לכל העסקאות העתידיות") {
                dismiss()
                onSelectForFuture(selection, trimmedNote)
                pendingCategory = nil
                noteText = ""
            }
            Button("בטל", role: .cancel) {
                pendingCategory = nil
            }
        } message: { selection in
            Text("האם לעדכן רק את העסקה הזו או להחיל את \(selection) על עסקאות עתידיות של \(transaction.business_name ?? "בית העסק")?")
        }
        .alert("להסתיר עסקאות מבית העסק?", isPresented: $showHideConfirmation) {
            Button("הסתר", role: .destructive) {
                dismiss()
                onHideBusiness()
            }
            Button("בטל", role: .cancel) { }
        } message: {
            Text("נוסיף את \(transaction.business_name ?? "בית העסק") לרשימת בתי העסק הנסתרים, כדי שעסקאות עתידיות ממנו לא יוצגו במסך האישור.")
        }
        .sheet(isPresented: $showSplitSheet) {
            SplitTransactionSheet(
                transaction: transaction,
                availableCategories: categories.map(\.name),
                onSubmit: { originalTransactionId, splits in
                    // Create safe copies of the values to ensure they're valid
                    let safeId = String(originalTransactionId)
                    let safeSplits = Array(splits) // Ensure we have a copy of the array
                    handleSplitSubmission(originalTransactionId: safeId, splits: safeSplits)
                },
                onSuccess: {
                    showSplitSheet = false
                    dismiss()
                }
            )
        }
    }

    private func dismissKeyboardIfNeeded() {
        guard focusedField != nil else { return }
        focusedField = nil
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }

    @ViewBuilder
    private var splitSection: some View {
        if isSplitTransaction {
            VStack(alignment: .trailing, spacing: 8) {
                HStack {
                    Image(systemName: "arrow.triangle.branch")
                        .foregroundColor(.accentColor)
                    Text("העסקה כבר פוצלה")
                        .font(.body.weight(.semibold))
                }
                .frame(maxWidth: .infinity, alignment: .trailing)

                if let snippet = splitReferenceText {
                    Text(snippet)
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.trailing)
                        .frame(maxWidth: .infinity, alignment: .trailing)
                } else if let note = transaction.notes {
                    Text(note)
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.trailing)
                        .frame(maxWidth: .infinity, alignment: .trailing)
                }

                Text("תוכל למצוא את שתי העסקאות הנפרדות במסך הדוחות או לבטל את הפיצול מהדפדפן.")
                    .font(.caption)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.trailing)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(Color(UIColor.systemGray5))
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        } else {
            Button {
                dismissKeyboardIfNeeded()
                showSplitSheet = true
            } label: {
                VStack(alignment: .trailing, spacing: 6) {
                    HStack {
                        Image(systemName: "square.split.2x2")
                            .font(.body.weight(.semibold))
                        Text("פצל עסקה")
                            .font(.body.weight(.semibold))
                    }
                    .frame(maxWidth: .infinity, alignment: .trailing)
                    Text("חלק את החיוב למספר קטגוריות וחודשיםabelle.")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.trailing)
                    Text("הסכום הכולל נשמר ומועבר לקטגוריות שונות בהתאם לשדות שתזין.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.trailing)
                }
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding()
                .background(Color.accentColor.opacity(0.12))
                .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                .shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: 6)
            }
            .buttonStyle(.plain)
        }
    }

    private func toggleCategoryPicker() {
        withAnimation(.spring(response: 0.3, dampingFraction: 0.85, blendDuration: 0.2)) {
            isCategoryPickerExpanded.toggle()
            if !isCategoryPickerExpanded {
                dismissKeyboardIfNeeded()
            }
        }
    }

    private func toggleNoteEditor() {
        withAnimation(.spring(response: 0.3, dampingFraction: 0.85, blendDuration: 0.2)) {
            isNoteEditorExpanded.toggle()
        }
        if isNoteEditorExpanded {
            DispatchQueue.main.async {
                focusedField = .note
            }
        } else {
            dismissKeyboardIfNeeded()
        }
    }

    private func presentCategoryConfirmation() {
        guard pendingCategory != nil else { return }
        dismissKeyboardIfNeeded()
        DispatchQueue.main.async {
            showFutureChoice = true
        }
    }

    @ViewBuilder
    private var headerSection: some View {
        VStack(alignment: .trailing, spacing: 4) {
            Text(transaction.business_name ?? "ללא שם")
                .font(.headline)
            Text("בחר קטגוריה חדשה לעסקה זו.")
                .font(.footnote)
                .foregroundColor(.secondary)
        }
    }

    @ViewBuilder
    private var actionButtons: some View {
        ActionButton(
            title: "שנה קטגוריה",
            subtitle: isCategoryPickerExpanded ? "הסתר רשימת קטגוריות" : "הצג רשימת קטגוריות",
            systemImage: "slider.horizontal.3",
            isActive: isCategoryPickerExpanded
        ) {
            toggleCategoryPicker()
        }
        ActionButton(
            title: trimmedNote ?? "הוסף הערה",
            subtitle: noteButtonSubtitle,
            systemImage: "square.and.pencil",
            isActive: isNoteEditorExpanded || trimmedNote != nil
        ) {
            toggleNoteEditor()
        }
    }

    @ViewBuilder
    private var categoryPickerSection: some View {
        if isCategoryPickerExpanded {
            VStack(alignment: .trailing, spacing: 12) {
                TextField("חפש קטגוריה", text: $searchText)
                    .textFieldStyle(.roundedBorder)
                    .textInputAutocapitalization(.never)
                    .disableAutocorrection(true)
                    .multilineTextAlignment(.trailing)
                    .focused($focusedField, equals: .search)
                if categories.isEmpty {
                    VStack(spacing: 8) {
                        ProgressView()
                        Text("טוען קטגוריות זמינות...")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 40)
                } else {
                    ScrollView {
                        LazyVStack(alignment: .trailing, spacing: 12) {
                            ForEach(filteredCategories) { category in
                                let isSelected = pendingCategory == category.name
                                Button {
                                    withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) {
                                        pendingCategory = category.name
                                    }
                                } label: {
                                    HStack {
                                        Image(systemName: isSelected ? "checkmark.circle.fill" : "arrowshape.left.fill")
                                            .foregroundColor(isSelected ? .accentColor : .secondary)
                                        Spacer()
                                        Text(category.name)
                                            .font(.body.weight(.medium))
                                    }
                                    .padding()
                                    .frame(maxWidth: .infinity)
                                    .background(
                                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                                            .fill(isSelected ? Color.accentColor.opacity(0.15) : Color(UIColor.systemGray5))
                                    )
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                                            .stroke(isSelected ? Color.accentColor.opacity(0.6) : .clear, lineWidth: 1.5)
                                    )
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                    .frame(maxHeight: 260)
                }
            }
            .padding()
            .background(Color.cardBackground)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .transition(.opacity.combined(with: .move(edge: .top)))
        }
    }

    @ViewBuilder
    private var noteEditorSection: some View {
        if isNoteEditorExpanded {
            VStack(alignment: .trailing, spacing: 8) {
                Text("הוסף הערה (אופציונלי)")
                    .font(.subheadline.weight(.semibold))
                    .frame(maxWidth: .infinity, alignment: .trailing)
                ZStack(alignment: .topTrailing) {
                    if trimmedNote == nil {
                        Text("לדוגמה: בדיקה מול הנה\"ח")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                            .padding(.top, 18)
                            .padding(.horizontal, 18)
                            .frame(maxWidth: .infinity, alignment: .trailing)
                    }
                    TextEditor(text: $noteText)
                        .frame(minHeight: 110, maxHeight: 160)
                        .padding(12)
                        .background(Color.clear)
                        .multilineTextAlignment(.trailing)
                        .focused($focusedField, equals: .note)
                }
                .background(Color(UIColor.systemGray5))
                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            .padding()
            .background(Color.cardBackground)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .transition(.opacity.combined(with: .move(edge: .top)))
        }
    }

    @ViewBuilder
    private var confirmSection: some View {
        VStack(alignment: .trailing, spacing: 10) {
            HStack {
                if let pendingCategory {
                    Text(pendingCategory)
                        .font(.body.weight(.semibold))
                        .foregroundColor(.accentColor)
                        .lineLimit(1)
                        .truncationMode(.tail)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 6)
                        .background(Color.accentColor.opacity(0.15))
                        .clipShape(Capsule())
                } else {
                    Text("בחר קטגוריה ואז אשר את השינוי")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }
                Spacer(minLength: 0)
            }
            .frame(maxWidth: .infinity, alignment: .trailing)

            Button {
                presentCategoryConfirmation()
            } label: {
                Text("אשר שינוי קטגוריה")
                    .font(.body.weight(.semibold))
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(pendingCategory == nil ? Color(UIColor.systemGray5) : Color.accentColor.opacity(0.2))
                    .foregroundColor(pendingCategory == nil ? .secondary : .accentColor)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            .buttonStyle(.plain)
            .disabled(pendingCategory == nil)

            if pendingCategory != nil {
                Button(role: .cancel) {
                    withAnimation(.spring(response: 0.3, dampingFraction: 0.85)) {
                        pendingCategory = nil
                    }
                } label: {
                    Text("נקה בחירה")
                        .font(.footnote.weight(.semibold))
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity)
                }
            }
        }
        .padding()
        .background(Color.cardBackground)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }

    private func handleSplitSubmission(originalTransactionId: String, splits: [SplitTransactionEntry]) {
        // Add safety checks before accessing the parameters
        guard !originalTransactionId.isEmpty else {
            print("❌ [SPLIT DEBUG] Original transaction ID is empty")
            return
        }

        guard !splits.isEmpty else {
            print("❌ [SPLIT DEBUG] Splits array is empty")
            return
        }

        // Test safe access to the parameters before logging
        let safeId = originalTransactionId

        logSplitReception(originalTransactionId: safeId, splits: splits)
        onSplit(safeId, splits)
    }

    private func logSplitReception(originalTransactionId: String, splits: [SplitTransactionEntry]) {
        // Safe logging by accessing values first
        let safeId = String(originalTransactionId)
        let safeSplitsCount = splits.count
        print("🔍 [SPLIT DEBUG] onSubmit received data — id:", safeId, "splits:", safeSplitsCount)

        if safeSplitsCount > 0 {
            let safePreview = Array(splits.prefix(3)) // Convert to Array for safety
            for (index, entry) in safePreview.enumerated() {
                // Access properties safely
                let amount = entry.amount
                let category = String(entry.category)
                let flowMonth = String(entry.flowMonth)
                print("    ↳ Split #", index, "amount=", amount, "category=", category, "flow_month=", flowMonth)
            }
            if safeSplitsCount > safePreview.count {
                print("    … ועוד", safeSplitsCount - safePreview.count, "פיצולים")
            }
        }
    }
}

private struct ActionButton: View {
    var title: String
    var subtitle: String
    var systemImage: String
    var isActive: Bool
    var action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 12) {
                VStack(alignment: .trailing, spacing: 4) {
                    Text(title)
                        .font(.body.weight(.semibold))
                        .multilineTextAlignment(.trailing)
                        .lineLimit(1)
                        .truncationMode(.tail)
                    Text(subtitle)
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.trailing)
                        .lineLimit(1)
                        .truncationMode(.tail)
                }
                Spacer(minLength: 0)
                Image(systemName: systemImage)
                    .font(.body.weight(.semibold))
                    .foregroundColor(isActive ? .accentColor : .secondary)
            }
            .padding()
            .frame(maxWidth: .infinity)
            .background(isActive ? Color.accentColor.opacity(0.12) : Color(UIColor.systemGray5))
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
            .shadow(color: Color.black.opacity(0.06), radius: 8, x: 0, y: 4)
        }
        .buttonStyle(.plain)
    }
}

private struct RTLProgressBar: View {
    let progress: Double
    let tint: Color
    @Environment(\.layoutDirection) private var layoutDirection

    var body: some View {
        GeometryReader { proxy in
            ZStack(alignment: layoutDirection == .rightToLeft ? .trailing : .leading) {
                Capsule()
                    .fill(Color.primary.opacity(0.08))
                    .frame(width: proxy.size.width, height: proxy.size.height)
                Capsule()
                    .fill(tint)
                    .frame(width: proxy.size.width * CGFloat(max(0, min(progress, 1))), height: proxy.size.height)
            }
        }
        .frame(height: 8)
    }
}

private struct SwipeableTransactionCard: View {
    let transaction: Transaction
    let isTopCard: Bool
    let dragOffset: CGSize
    let theme: TransactionCardTheme
    let baseRotation: Double

    @Environment(\.layoutDirection) private var layoutDirection

    private var effectiveCategory: String {
        transaction.effectiveCategoryName.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    var body: some View {
        VStack(alignment: .trailing, spacing: 28) {
            categoryHeader
            heroAmountSection
            heroDetailsSection
        }
        .multilineTextAlignment(.trailing)
        .padding(.vertical, 32)
        .padding(.horizontal, 30)
        .frame(maxWidth: .infinity, alignment: .trailing)
        .background(
            RoundedRectangle(cornerRadius: 32, style: .continuous)
                .fill(theme.gradient)
        )
        .overlay(alignment: .topTrailing) {
            iconStamp
        }
        .overlay { overlayLabels }
        .offset(x: directionalOffset.width, y: directionalOffset.height)
        .rotationEffect(.degrees(isTopCard ? Double(normalizedDragWidth / 10) : baseRotation))
        .animation(.interactiveSpring(), value: dragOffset)
    }

    private var categoryHeader: some View {
        VStack(alignment: .trailing, spacing: 6) {
            if !effectiveCategory.isEmpty {
                Text(effectiveCategory)
                    .font(.footnote.weight(.semibold))
                    .foregroundColor(.primary)
                    .padding(.vertical, 6)
                    .padding(.horizontal, 16)
                    .background(
                        Capsule()
                            .fill(theme.accentSoft.opacity(0.4))
                    )
            }
        }
        .frame(maxWidth: .infinity, alignment: .trailing)
    }

    private var heroAmountSection: some View {
        VStack(spacing: 10) {
            Text(transaction.isIncome ? "נכנס" : "יצא")
                .font(.caption)
                .foregroundColor(.secondary)
            HStack(spacing: 6) {
                Text(transaction.currency ?? "₪")
                    .font(.title3.weight(.medium))
                Text(formatAmount(transaction.absoluteAmount))
                    .font(.system(size: 46, weight: .heavy, design: .rounded))
                    .foregroundColor(theme.accent)
                    .monospacedDigit()
            }
            .environment(\.layoutDirection, .leftToRight)
        }
        .frame(maxWidth: .infinity)
    }

    private var heroDetailsSection: some View {
        let lines = heroDetailLines
        return VStack(spacing: 6) {
            ForEach(Array(lines.enumerated()), id: \.offset) { detail in
                Text(detail.element)
                    .font(.footnote.weight(.medium))
                    .foregroundColor(.primary.opacity(0.85))
            }
        }
        .frame(maxWidth: .infinity)
        .multilineTextAlignment(.center)
    }

    private var heroDetailLines: [String] {
        var lines: [String] = []
        if let merchant = merchantLine { lines.append(merchant) }
        if let paymentDate = formattedPaymentDate { lines.append(paymentDate) }
        if let reference = referenceLine { lines.append(reference) }
        return lines
    }

    private var merchantLine: String? {
        guard let name = transaction.business_name?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty else {
            return nil
        }
        return name
    }

    private var referenceLine: String? {
        if let method = transaction.payment_method?.trimmingCharacters(in: .whitespacesAndNewlines), !method.isEmpty {
            return method
        }
        return formattedCreatedAt
    }

    private var iconStamp: some View {
        Circle()
            .fill(Color.white.opacity(0.7))
            .frame(width: 44, height: 44)
            .overlay(
                Image(systemName: theme.symbol)
                    .foregroundColor(theme.accent)
            )
            .padding(16)
    }

    private var formattedPaymentDate: String? {
        guard let parsed = transaction.parsedDate else { return nil }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "he_IL")
        formatter.dateStyle = .medium
        return formatter.string(from: parsed)
    }

    private var formattedCreatedAt: String? {
        guard let created = transaction.createdAtDate else { return nil }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "he_IL")
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter.string(from: created)
    }

    private func formatAmount(_ value: Double) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .decimal
        formatter.maximumFractionDigits = 0
        formatter.locale = Locale(identifier: "he_IL")
        return formatter.string(from: NSNumber(value: value)) ?? "\(value)"
    }

    private var normalizedDragWidth: CGFloat {
        layoutDirection == .rightToLeft ? -dragOffset.width : dragOffset.width
    }

    private var directionalOffset: CGSize {
        layoutDirection == .rightToLeft
        ? CGSize(width: -dragOffset.width, height: dragOffset.height)
        : dragOffset
    }

    private var approveAlignment: Alignment {
        layoutDirection == .rightToLeft ? .topLeading : .topTrailing
    }

    private var approvePaddingEdge: Edge.Set {
        layoutDirection == .rightToLeft ? .leading : .trailing
    }

    private var categoryAlignment: Alignment {
        layoutDirection == .rightToLeft ? .topTrailing : .topLeading
    }

    private var categoryPaddingEdge: Edge.Set {
        layoutDirection == .rightToLeft ? .trailing : .leading
    }

    @ViewBuilder
    private var overlayLabels: some View {
        if normalizedDragWidth > 30 {
            label(text: "לאשר", color: .green)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: approveAlignment)
                .padding(.top, 18)
                .padding(approvePaddingEdge, 24)
        } else if normalizedDragWidth < -30 {
            label(text: "שינוי קטגוריה", color: .orange)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: categoryAlignment)
                .padding(.top, 18)
                .padding(categoryPaddingEdge, 24)
        }
    }

    private func label(text: String, color: Color) -> some View {
        Text(text)
            .font(.caption.bold())
            .padding(.vertical, 6)
            .padding(.horizontal, 12)
            .background(color.opacity(0.15))
            .clipShape(Capsule())
    }
}
