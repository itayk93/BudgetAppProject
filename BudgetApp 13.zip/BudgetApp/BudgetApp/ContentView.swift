//
//  ContentView.swift
//  BudgetApp
//
//  Created by itay karkason on 19/10/2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Text("This view is no longer used. The app now uses RootView with authentication.")
            .padding()
    }
}

#Preview {
    ContentView()
}
